
<?php //echo '<pre>'; var_dump($data); die; ?>

<?php //echo '<pre>'; print_r($data); ?>
<?php //print render($data['name']);  ?>
<?php //print drupal_render_children($data);  ?>
<?php //print($data['name']); ?>
<?php //print drupal_render($data['info']['name']); ?>
<?php //print drupal_render_children($data); ?>
 <?php //print drupal_render($data['name']); ?>
 <div class="form">
<h1>RECEIVE UPDATES, DISCOUNT OFFERS & EXHIBITION INVITES</h1>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="right" valign="middle">Name *</td>
    <td align="left" valign="middle"><?php print drupal_render($data['name']);  ?></td>
  </tr>
  <tr>
    <td align="right" valign="middle">E-Mail *</td>
    <td align="left" valign="middle"><?php print drupal_render($data['email']);  ?></td>
  </tr>
   <tr>
    <td align="right" valign="middle">Address<br><small>(Optional)</small></td>
    <td align="left" valign="middle"><?php print drupal_render($data['address']);  ?></td>
  </tr>
   <tr>
    <td align="right" valign="middle">City<br><small>(Optional)</small></td>
    <td align="left" valign="middle"><?php print drupal_render($data['city']);  ?></td>
  </tr>
   <tr>
    <td align="right" valign="middle">Postcode<br><small>(Optional)</small></td>
    <td align="left" valign="middle"><?php print drupal_render($data['postcode']);  ?></td>
  </tr>
   <tr>
    <td align="right" valign="middle"><small>* required</small></td>
    <td align="left" valign="middle"><?php print drupal_render($data['submit']);  ?></td>
  </tr>
  
</table>
</div>
 <?php print drupal_render_children($data); ?>